const sass = require('node-sass');
const fs = require('fs');
sass.render({
  file: './.scss/scss.scss'
}, (e, res) => {
    if(e){
        console.log('Failed to compile SCSS. \n'+e)
    }else{
        fs.writeFile('./.css/css.css', res.css, err => {
            if(err) throw err;

            console.log('CSS compiled successfully.');
        })
    }
});